SELECT COUNT(*)
FROM procedures_icd
WHERE subject_id = '10000117';